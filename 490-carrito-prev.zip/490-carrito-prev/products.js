const motos = [
  {id:"motoss-01",product: 'NKD',price: 4000000,image:  '/imagenes/nkd.jpg'}, 
  {id:"motoss-02",product: 'HERO',price: 6000000,image: '/imagenes/hero.jpg'},
  {id:"motoss-03",product: 'BMW',price: 1000000,image: '/imagenes/bmw.jpg'},
  {id:"motoss-04",product: 'KTM',price: 9000000,image:  '/imagenes/ktm.jpg'},
  {id:"motoss-05",product: 'PULSAR',price: 5000000,image: '/imagenes/pulsar.jpg'},
  {id:"motoss-06",product: 'SUZUKI',price: 45000000,image: '/imagenes/suzuki.jpeg'},
  {id:"motoss-07",product: 'TVS',price: 55000000,image:  '/imagenes/tvs.jpg'},
  {id:"motoss-08",product: 'DUCATI',price: 11000000,image: '/imagenes/ducati.jpg'},
  {id:"motoss-09",product: 'MT 09',price: 20000000,image: '/imagenes/mt.jpg'},
  {id:"motoss-10",product: 'KAWASAKI',price: 17000000,image: '/imagenes/kawasaki.jpg'},
];